function searchBooks() {
  let query = document.getElementById("searchBar").value;
  if (query.trim() === "") {
    alert("Please enter a book name to search!");
  } else {
    alert("Searching for: " + query);
  }
}
