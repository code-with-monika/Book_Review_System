function fetchReviews() {
  const bookName = document.getElementById("bookSelect").value.trim();
  let url = 'get_reviews.php';
  if(bookName) {
      url += '?book=' + encodeURIComponent(bookName);
  }

  fetch(url)
    .then(res => res.json())
    .then(data => {
      const tbody = document.querySelector("#reviewTable tbody");
      tbody.innerHTML = "";

      if(data.length === 0){
        tbody.innerHTML = `<tr><td colspan="3">No reviews found.</td></tr>`;
        return;
      }

      data.forEach(r => {
        const row = document.createElement("tr");
        row.innerHTML = `<td>${r.userName}</td><td>${r.bookName}</td><td>${r.review}</td>`;
        tbody.appendChild(row);
      });
    })
    .catch(err => console.error(err));
}
