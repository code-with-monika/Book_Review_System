// groups.js

function joinGroup(groupName) {
    // Select all group divs
    const groups = document.querySelectorAll('.group');

    groups.forEach(group => {
        const title = group.querySelector('h3').textContent.trim();
        if (title === groupName) {
            const membersP = group.querySelector('p');

            // Extract current number of members
            let count = parseInt(membersP.textContent.match(/\d+/)[0]); // extract number

            // Increment count
            count += 1;

            // Update the text inside <p>
            membersP.textContent = `Members: ${count}`;

            // Disable the button and change text
            const button = group.querySelector('button');
            button.textContent = 'Joined';
            button.disabled = true;
        }
    });
}
