const searchBar = document.getElementById('searchBar');
const searchBtn = document.getElementById('searchBtn');
const bookList = document.getElementById('book-list');

function displayBooks(books) {
  bookList.innerHTML = '';
  if (books.length === 0) {
    bookList.innerHTML = `<p style="font-size:1.2em; margin-top:20px;">No books found</p>`;
    return;
  }

  books.forEach(book => {
    const bookCard = document.createElement('div');
    bookCard.classList.add('book-card');
    bookCard.innerHTML = `
      <img src="${book.cover_url}" alt="${book.title}">
      <h3>${book.title}</h3>
      <p>Author: ${book.author}</p>
      <p>⭐ ${book.rating} / 5</p>
      <button onclick="goToReviews()">See Reviews</button>
    `;
    bookList.appendChild(bookCard);
  });
}

function searchBooks() {
  const query = searchBar.value.trim();

  fetch('php/search_books.php', {
    method: 'POST',
    body: new URLSearchParams({ query })
  })
  .then(res => res.json())
  .then(data => {
    if (data.status === 'success') {
      displayBooks(data.books);
    } else {
      alert('Error fetching books');
    }
  })
  .catch(err => console.error(err));
}

searchBtn.addEventListener('click', searchBooks);
searchBar.addEventListener('keyup', function(e){
  if(e.key === 'Enter') searchBooks();
});

// Optional: Load all books initially
window.addEventListener('load', () => {
  searchBooks(); // load all books if search is empty
});
