// Example: Add book dynamically
document.getElementById("readingList").innerHTML += "<li>Clean Code</li>";
