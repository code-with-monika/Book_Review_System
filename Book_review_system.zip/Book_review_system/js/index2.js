function searchBooks() {
    const query = document.getElementById('searchBar').value.trim();
    const resultsDiv = document.getElementById('searchResults');
    resultsDiv.innerHTML = ''; // Clear previous results

    if (!query) {
        resultsDiv.innerHTML = '<p>Please enter a book name or author.</p>';
        return;
    }

    fetch(`php/search_books.php?q=${encodeURIComponent(query)}`)
        .then(response => response.json())
        .then(data => {
            if (data.length === 0) {
                resultsDiv.innerHTML = '<p>No books found.</p>';
                return;
            }

            data.forEach(book => {
                const bookCard = document.createElement('div');
                bookCard.classList.add('book-card');
                bookCard.innerHTML = `
                    <img src="${book.image_url}" alt="${book.title}">
                    <h3>${book.title}</h3>
                    <p>Author: ${book.author}</p>
                    <p>⭐ ${book.rating} / 5</p>
                    <button onclick="goToReviews('${book.title}')">See Reviews</button>
                `;
                resultsDiv.appendChild(bookCard);
            });
        })
        .catch(err => {
            console.error(err);
            resultsDiv.innerHTML = '<p>Error fetching books. Please try again.</p>';
        });
}
