<?php
include "db_connect.php";

$bookName = $_POST['bookName'] ?? '';
$review = $_POST['review'] ?? '';

if (!$bookName || !$review) {
    echo "Please provide both book name and review.";
    exit;
}

$sql = "INSERT INTO reviews (bookName, review) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $bookName, $review);

if ($stmt->execute()) {
    echo "✅ Review added successfully!";
} else {
    echo "❌ Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
