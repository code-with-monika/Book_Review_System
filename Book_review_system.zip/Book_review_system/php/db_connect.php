<?php
$host = "localhost";       // Your database host
$user = "root";            // Your MySQL username
$pass = "";                // Your MySQL password
$dbname = "book_review_system"; // Your database name

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]));
}
?>
