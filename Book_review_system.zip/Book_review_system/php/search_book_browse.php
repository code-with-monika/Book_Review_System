<?php
header('Content-Type: application/json');
include 'db_connect.php';

// Get the search query
$search = $_GET['q'] ?? '';
$search = trim($search);

if (!$search) {
    echo json_encode([]);
    exit;
}

// Case-insensitive search for title or author
$stmt = $conn->prepare("
    SELECT * FROM books 
    WHERE LOWER(title) LIKE LOWER(?) 
       OR LOWER(author) LIKE LOWER(?)"
);

$searchTerm = "%" . $search . "%";
$stmt->bind_param("ss", $searchTerm, $searchTerm);
$stmt->execute();
$result = $stmt->get_result();

$books = [];
while ($row = $result->fetch_assoc()) {
    $books[] = $row;
}

// Return results as JSON
echo json_encode($books);

$stmt->close();
$conn->close();
?>
