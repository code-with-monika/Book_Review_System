<?php
include "db_connect.php";

$result = $conn->query("SELECT bookName, review FROM reviews ORDER BY id DESC");
$reviews = [];

while ($row = $result->fetch_assoc()) {
    $reviews[] = $row;
}

header('Content-Type: application/json');
echo json_encode($reviews);
$conn->close();
?>
