<?php
header('Content-Type: application/json');
error_reporting(0); // Hide warnings

include 'db_connect.php';

$search = $_GET['q'] ?? '';
$search = trim($search);

if (!$search) {
    echo json_encode([]);
    exit;
}

// Prepare statement for case-insensitive search
$stmt = $conn->prepare("
    SELECT id, title, author, rating, image_url, created_at 
    FROM books 
    WHERE LOWER(title) LIKE LOWER(?) OR LOWER(author) LIKE LOWER(?)
");

$searchTerm = "%" . $search . "%";
$stmt->bind_param("ss", $searchTerm, $searchTerm);

if (!$stmt->execute()) {
    echo json_encode([]);
    exit;
}

$result = $stmt->get_result();
$books = [];

while ($row = $result->fetch_assoc()) {
    $books[] = [
        "id" => $row['id'],
        "title" => $row['title'],
        "author" => $row['author'],
        "rating" => $row['rating'],
        "cover_image" => $row['image_url'],
        "created_at" => $row['created_at']
    ];
}

echo json_encode($books);

$stmt->close();
$conn->close();
?>
